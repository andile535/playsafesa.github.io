package com.andiletest.andiletest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AndiletestApplication {

	public static void main(String[] args) {
		SpringApplication.run(AndiletestApplication.class, args);
	}

}
