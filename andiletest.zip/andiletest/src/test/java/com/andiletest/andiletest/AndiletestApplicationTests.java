package com.andiletest.andiletest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AndiletestApplicationTests {

	@Test
	void contextLoads() {
	}

}
